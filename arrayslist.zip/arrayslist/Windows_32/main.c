#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Employee.h"

/****************************************************
    Menu:
        1. Parse del archivo data.csv
        2. Listar Empleados
        3. Ordenar por nombre
        4. Agregar un elemento
        5. Elimina un elemento
        6. Listar Empleados (Desde/Hasta)
*****************************************************/


int main()
{
    int menu;
    char salir = 'n';
    int id = 0;
    Employee* employee;
    ArrayList* lista;


    do{
        printf("1. Parse del archivo data.csv \n 2. Listar Empleados\n 3. Ordenar por nombre\n 4. Agregar un elemento\n 5. Elimina un elemento\n 6. Listar Empleados (Desde/Hasta)\n 7. salir \n");
        scanf("%d",&menu);

        switch(menu)
        {

        case 1:

            break;

         case 2:

            break;
        case 3:

            break;

         case 4:

        employee = employee_new();
        employee_setId(employee, (id+1));
        id++;
        lista->add(lista, employee);

            break;
        case 5:

            break;

         case 6:

            break;

        case 7:
            printf("quiere salir 's'");
            fflush(stdin);
            scanf("%c",&salir);
            break;
         }
        }while(salir != 's');


    return 0;
}
