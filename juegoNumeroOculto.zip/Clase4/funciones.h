float getFloat(char mensaje[]);

char getChar(char mensaje[]);

int getInt(char mensaje[]);


int getNumeroAleatorio(int desde , int hasta , int iniciar);
